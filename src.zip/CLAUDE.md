# CLAUDE.md — RetroText Adventures

Developer reference for the AI text-adventure engine.

---

## Architecture

```
index.html          Entry point (Vite)
src/
  main.jsx          React root mount (no StrictMode — see below)
  App.jsx           All UI, state, phase machine, block renderer
  prompts.js        GENRES constant, buildInitPrompt(), buildActionPrompt()
  ascii.js          Fallback ASCII art per genre (mostly unused — model generates art)
api/
  generate.js       Vercel serverless function — proxies to Groq, keeps API key server-side
dev-server.js       Local Express proxy for /api/generate during development
vite.config.js      Vite config with /api proxy to dev-server
vercel.json         Rewrites /api/* to serverless functions
```

---

## How it works

### Block model
All visible content is a flat array of **blocks** (`useState`). There are no
separate screens or routes — everything appended to `blocks` renders in order
and the page scrolls naturally.

Block types: `text` · `dim` · `green` · `art` · `user` · `help` · `suggestions` · `gap` · `rule`

### Phase machine
```
welcome → genre → [custom-seed →] char → game
```
The `phase` state gates what `submit()` does with each Enter press. Slash
commands are only handled in the `game` phase (plus the toolbar buttons).

### LLM integration
- Model: `llama-3.1-8b-instant` via Groq (`/openai/v1/chat/completions`)
- The full system prompt is embedded in the user message (no system role used)
- The model is instructed to return **only valid JSON** with `story`, `art`, `suggestions`
- `parseResponse()` tries `JSON.parse` first, then falls back to regex extraction
  (handles literal newlines inside JSON string values, which the model occasionally emits)

### Conversation history
Kept in `history` state as `{role, content}` pairs. Trimmed to last 24 entries
(`slice(-24)`) to stay within context limits. Reset on `/new`.

---

## Running locally

```bash
# 1. Install
npm install

# 2. Set your Groq key
echo "GROQ_API_KEY=gsk_..." > .env.local

# 3. Start (Vite + Express proxy together)
npm run dev
```

`dev-server.js` runs Express on port 3001 and handles `/api/generate`.
Vite proxies `/api/*` there via `vite.config.js`.

## Deploying to Vercel

```bash
vercel deploy --prod
vercel env add GROQ_API_KEY   # paste key when prompted
```

`api/generate.js` becomes a serverless function. `vercel.json` rewrites
`/api/*` to it.

---

## Known issues fixed (2025-03-29)

### 1. Duplicate welcome text
**Root cause:** `React.StrictMode` in `main.jsx` invokes `useEffect` twice in
development. The welcome `useEffect` added blocks both times.

**Fix A (primary):** Removed `<React.StrictMode>` from `main.jsx`. Dev and prod
behaviour now match; no StrictMode warnings are relevant for this codebase.

**Fix B (belt-and-suspenders):** Added a `hasInit` ref guard in App.jsx so the
welcome effect is idempotent even if accidentally double-fired:
```js
const hasInit = useRef(false);
useEffect(() => {
  if (hasInit.current) return;
  hasInit.current = true;
  // ... add blocks
}, []);
```

---

### 2. Raw JSON printed as story text
**Root cause:** The model occasionally emits literal `\n` characters (actual
newline bytes) inside JSON string values (e.g. the `art` field). The JSON spec
forbids unescaped newlines in strings, so `JSON.parse` throws and the old code
fell back to printing the entire raw response as the story.

**Fix:** `parseResponse()` now has a two-stage approach:
1. `JSON.parse` on the cleaned string (fast path, works most of the time)
2. Regex field extraction that tolerates real newlines inside strings (fallback)

```js
const storyM = clean.match(/"story"\s*:\s*"([\s\S]*?)(?<!\\)",/);
const artM   = clean.match(/"art"\s*:\s*(?:(null)|"([\s\S]*?)(?<!\\)")/);
```

---

### 3. Auto-scroll fighting manual scroll
**Root cause:** `scrollIntoView` fired on every `blocks` change, pulling the
user back to the bottom even when they'd scrolled up to re-read earlier content.

**Fix:** Added an `autoScroll` ref that tracks whether the user is within 160px
of the bottom. Auto-scroll only fires when they are. Submitting any action
resets `autoScroll` to `true` (force-scrolls to bottom):

```js
const autoScroll = useRef(true);
// in onScroll listener:
autoScroll.current = distFromBottom < 160;
// in submit():
autoScroll.current = true; scrollToBottom(true);
```

---

### 4. Commands not discoverable / /help not visible
**Root cause:** Commands existed in `handleSlash` but nothing surfaced them.
`/help` only worked after the user already knew to type it.

**Fix:** Added a command toolbar above the text input, visible only during
`phase === 'game'`:
- **NEW** — `/new` (restart same character & genre)  
- **COPY** — `/copy` (copy full adventure to clipboard)
- **RESTART** — `/restart` (back to start screen)
- **HELP** — `/help` (show command list)

---

## Adding a new genre

In `src/prompts.js`, add an entry to the `GENRES` array:

```js
{ id: 'pirate', label: 'PIRATE', seed: 'Your ship is sinking. The treasure is still aboard.' },
```

If you want fallback art, add a matching key to `ART` in `src/ascii.js`.

---

## Adding a new slash command

1. Add the handler branch in `handleSlash()` in `App.jsx`
2. Add a line to the `HELP` string constant
3. Optionally add a button to `CMD_BTNS` in the render section

---

## Prompt tuning

Edit `SYSTEM` in `src/prompts.js` to change the narrator's behaviour, art
style, or JSON schema. The model is `llama-3.1-8b-instant` — fast and free on
Groq but not very instruction-following. If responses keep breaking JSON, either:
- Increase `max_tokens` in `api/generate.js` (currently 400 — sometimes the
  JSON gets truncated mid-art, causing parse failures)
- Upgrade to `llama-3.3-70b-versatile` for better instruction following
- Add explicit JSON validation / retry logic in `callGroq()`
